const database = require('../models/con_db');


const register = (req, res, next) => {
    let firstname = req.body.first_name;
    let lastname = req.body.last_name;
    let username = req.body.username;
    let password = req.body.password;
    let User = {
        first_name: firstname,
        last_name: lastname,
        username: username,
        password: password
        }
        let query = `INSERT INTO appointment SET ?`;
        database.database.query(query, User,(error, rows, result) => {
            if (error) {
                console.log(error)
              res.status(500).json({
                successful: false,
                message: error
              })
            }
            else {
                // Invalid username or password
                res.status(200).json({
                  successful: true,
                  message: "succesfully registered a user"
                });
            }
        })
}


module.exports = {
    register
  };
