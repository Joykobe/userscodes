const express = require('express')
const userController = require('../controllers/user.controller')

const userRouter = express.Router()


 userRouter.post('/register', userController.register)
// cusRouter.post('/add-customer', cusController.addCustomer)
// cusRouter.get('/view/:id', cusController.viewCustomer)
// cusRouter.put('/update-customer/:id', cusController.updateCustomer)
// cusRouter.put('/update-username/:id', cusController.updateUsername)
// cusRouter.put('/update-password/:id', cusController.updatePassword)




module.exports = userRouter